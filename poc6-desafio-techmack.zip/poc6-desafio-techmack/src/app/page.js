import styles from "./page.module.css";
import info from "./info.json";

export default function Home() {
  
    const filmeInfo = () => {
      return (
        <header>
          <h1>{info.titulo}</h1>
          <h2>{info.horario}</h2>
        </header>
      );
    };

    const filmeDesc = () => {
      return (
        <header>
          <b>Sinopse</b>
          <p>{info.sinopse}</p>
          <b>Data de Lançamento</b>
          <p>{info.dataLancamento}</p>
          <b>Direção</b>
          <p>{info.direcao}</p>
          
        </header>
      );
    };

    const exibirCadeiras = () => {
      return info.assentos.map((assento) => (
        <button key={assento.numero} className={styles.assentos}>
          {assento.numero}
        </button>
      ));
    };
    
    return(
      <div className={styles.body}>
        <div className={styles.container}>
          {filmeInfo()}
          <section className={styles.containerDirection}>
            <div className={styles.containerLeft}>
              <div className={styles.cadeirasContainer}>
                {exibirCadeiras()}
                <h2>Tela</h2>
                <hr className={styles.tela}></hr>
                <section className={styles.categorias}>
                  <p className={styles.categoria}> <input type="radio" className={styles.circulos}></input>livre</p>
                  <p className={styles.categoria}> <input type="radio" className={styles.circulos}></input>selecionado</p>
                  <p className={styles.categoria}> <input type="radio" className={styles.circulos}></input>indisponível</p>
                </section>
              </div>
            </div> 
            <div className={styles.containerRight}>
              {filmeDesc()}
            </div>
          </section>
          <button className={styles.button}>Comprar</button>
        </div>
        
      </div>
    );
  
    
}
