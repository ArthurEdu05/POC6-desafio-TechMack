"use client";

import { useState, useEffect } from "react";
import styles from "./page.module.css";
import info from "./info.json";

export default function Home() {
  const seatPreco = 25; // Preço de cada assento
  const [selecionaAssento, setSelecionaAssento] = useState([]);
  const [totalPreco, setTotalPreco] = useState(0);

  useEffect(() => {
    // Atualiza o preço total sempre que a seleção de assentos mudar
    setTotalPreco(selecionaAssento.length * seatPreco);
  }, [selecionaAssento]);

  const toggleSeatSelection = (numAssento) => {
    if (selecionaAssento.includes(numAssento)) {
      setSelecionaAssento(selecionaAssento.filter((num) => num !== numAssento));
    } else {
      setSelecionaAssento([...selecionaAssento, numAssento]);
    }
  };

  const filmeInfo = () => (
    <header>
      <h1>{info.titulo}</h1>
      <h2 className={styles.horario}>{info.horario}</h2>
    </header>
  );

  const filmeDesc = () => (
    <header>
      <b className="titulo">Sinopse do filme</b>
      <p>{info.sinopse}</p>
      <b>Data de Lançamento</b>
      <p>{info.dataLancamento}</p>
      <b>Direção</b>
      <p>{info.direcao}</p>
    </header>
  );

  const exibirCadeiras = () =>
    info.assentos.map((assento) => {
      const isSelected = selecionaAssento.includes(assento.numero);
      const seatClass = assento.disponivel
        ? isSelected
          ? styles.assentoSelecionado
          : styles.assentoDisponivel
        : styles.assentoIndisponivel;

      return (
        <button
          key={assento.numero}
          className={`${styles.assentos} ${seatClass}`}
          onClick={() => assento.disponivel && toggleSeatSelection(assento.numero)}
          disabled={!assento.disponivel}
        />
      );
    });

  return (
    <div className={styles.body}>
      <div className={styles.container}>
        {filmeInfo()}
        <section className={styles.containerDirection}>
          <div className={styles.containerLeft}>
            <div className={styles.cadeirasContainer}>
              {exibirCadeiras()}
              <h2>Tela</h2>
              <hr className={styles.tela} />
              <section className={styles.categorias}>
                <p className={styles.categoria}>
                  <input type="radio" className={styles.circulos} defaultChecked /> livre
                </p>
                <p className={styles.categoria}>
                  <input type="radio" className={styles.circuloss} defaultChecked /> selecionado
                </p>
                <p className={styles.categoria}>
                  <input type="radio" className={styles.circulo} defaultChecked /> indisponível
                </p>
              </section>
            </div>
          </div>
          <div className={styles.containerRight}>{filmeDesc()}</div>
        </section>
        <button className={styles.button}>Comprar: R${totalPreco.toFixed(2)}</button>
      </div>
    </div>
  );
}
