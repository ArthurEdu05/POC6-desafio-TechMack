import styles from "./page.module.css";
import info from "./info.json";

export default function Home() {
  
    const filmeInfo = () => {
      return (
        <header>
          <h1>{info.titulo}</h1>
          <h2>{info.horario}</h2>
        </header>
      );
    };

    const filmeDesc = () => {
      return (
        <header>
          <b>Sinopse</b>
          <p>{info.sinopse}</p>
          <b>Data de Lançamento</b>
          <p>{info.dataLancamento}</p>
          <b>Direção</b>
          <p>{info.direcao}</p>
          
        </header>
      );
    };
    
    return(
      <div className={styles.body}>
        <div className={styles.container}>
          {filmeInfo()}
          <section className={styles.containerDirection}>
            <div className={styles.containerLeft}>
              <p>Aqui teremos as cadeiras!</p>
            </div> 
            <div className={styles.containerRight}>
              {filmeDesc()}
            </div>
          </section>
          <button className={styles.button}>Comprar</button>
        </div>
        
      </div>
    );
  
    
}
